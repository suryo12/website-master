import requests
import json
import time, datetime
from datetime import datetime, date, time

server_domain = 'http://localhost:8000/'
app = 'smart/api/'


def post_data():
    url = server_domain + app
    headers = {'content-type': 'application/json'}
    data = {#"node_name" : "Magelang1",
            #"location" : "Magelang Km 10",
            "node_id" : 1,
            "tegangan" : 3,
            "arus" : 3,
            "daya" :3,
            "tanggal" : date(int(2018),int(01),int(20)),
            "waktu" : datetime.now()
            #tanggal = models.DateField(db_index=True, null=True, default=None)
            #waktu = models.TimeField(db_index=True, null=True, default=None)


            #"waktu" : datetime.time(11, 30)
          }

    response = requests.post(url, data=json.dumps(data), headers =headers)

    if response.status_code != 201:
        print('Error: {}'.format(response.text))
    else:
        print('Created: {}'.format(json.loads(response.text)))


if __name__ == '__main__':
    post_data()
