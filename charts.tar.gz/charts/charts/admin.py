from django.contrib import admin
from .models import Customer, EnergyData

admin.site.register(Customer)
admin.site.register(EnergyData)
# Register your models here.
